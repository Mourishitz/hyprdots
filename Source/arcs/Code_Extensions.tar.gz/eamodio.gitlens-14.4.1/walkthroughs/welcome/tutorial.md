<figure align="center">
  <img src="tutorial.png" alt="GitLens Tutorial" />
</figure>
