# Mono

Based on [crt-themes](https://github.com/krueger71/crt-themes) but with errors/warnings highlight

## White

![White](https://github.com/stepanvanzuriak/mono/raw/master/media/white.png)

## Dark

![Dark](https://github.com/stepanvanzuriak/mono/raw/master/media/dark.png)
